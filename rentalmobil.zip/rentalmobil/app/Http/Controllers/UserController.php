<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\User;

class UserController extends Controller
{
    //menampilkan data
    public function user()
    {
        $userData = User::get();
        return view('pages.user.user', compact('userData'));
    }

    //menambahkan data
    function store(Request $request)
    {
        //validasi data yang masuk
        $userData = $request->validate([
            'user' => 'required',
        ]);
        //simpan kedalam database
        User::create($userData);
        //mengalihkan ke halaman awal
        return redirect()->to('/userdata');
    }

    //hapus data
    function delete($id)
    {
        User::find($id)->delete();

        return redirect()->to('/userdata');
    }
}