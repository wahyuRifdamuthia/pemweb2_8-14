<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;

class RegisterController extends Controller
{
    //memangiil form
    function index()
    {
        return view('pages.auth.register');
    }

    //memprogres registrasi pengguna
    function register(Request $request)
    {
        //validasi data
        $validateUser = $request->validate([
            'name'=> 'required',
            'contact'=>'required',
            'email'=> 'required|unique:users',
            'password'=> 'required',
        ]);

        //proses registrasi pengguna
        $userData = new User;
        $userData->name = $request->name;
        $userData->contact = $request->contact;
        $userData->email = $request->email;
        $userData->password = bcrypt($request->password);
        $userData->save();

        //redirect / alih halaman
        return redirect()->to('/login')->with('sukses', 'registrasi berhasil');
    }
}