<?php
    $arrayMobil = ['SUV', 'Hacthbag', 'Sedan', 'MPV'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php $__empty_1 = true; $__currentLoopData = $arrayMobil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <h2><?php echo e($mobil); ?></h2>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h2> kosong </2>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\kuliahwahyurifda\rentalmobil\resources\views/greeting.blade.php ENDPATH**/ ?>